# LC1_Atif_AutomateCity_CorePHP

This is a portfolio website for Muhammad Atif (Local Client 1). The reference website is (https://theleagueofecom.com/).
