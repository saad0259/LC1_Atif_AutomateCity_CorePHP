<?php
$serverName = "localhost"; 
$dBUsername = "root";
$dBPassword = ""; 
$dBName = "automatecitydb01";

// wwA#ftwUCp.L


?>