<?php
include('includes/header.php');

?>


	<!-- Blog Single -->
    <section class="news-area archive blog-single section-padding">
			<div class="container">
				<div class="row">
					<div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-12">
						<div class="row">
							<div class="col-12">
								<div class="blog-single-main">
									
									<div class="blog-detail">
										<!-- News meta -->
										<ul class="news-meta">
											<li><i class="fa fa-user"></i>AutomateCity</li>
											<li><i class="fa fa-pencil"></i>April 15, 2020</li>
											<li><i class="fa fa-dollar"></i>0 Purchases</li>
										</ul>
										<h2 class="blog-title">Service Name</h2>
										<p>Sed tempus pulvinar augue ut euismod. Donec a nisi volutpat, dignissim mauris eget. Quisque vitae nunc sit amet eros pellentesque tempus at sit amet sem. Maecenas feugiat mauris non scelerisque venenatis. Sed non rutrum sem. Duis eget lectus vitae orci pellentesque viverra a non magna. Aenean maximus, nisl non porttitor feugiat, felis odio pretium elit, nec lobortis ante augue non enim. Aliquam tempor dui vel libero suscipit laoreet. Aenean varius, lorem vitae vulputate efficitur, tortor tellus tristique diam, a vulputate est quam feugiat ex. Sed posuere nisi nibh, a tristique enim euismod</p>
										<div class="row blog-space">
											<div class="col-lg-6">
												<img src="https://via.placeholder.com/455x515" alt="#">
											</div>
											<div class="col-lg-6">
												<h5>Features</h5>
												<ul>
													<li>We’re creative thinker</li>
													<li>We give you free consulting service</li>
													<li>Included top level domain every package</li>
													<li>Great way to represent your business</li>
													<li>99% Server Up-time guarantee</li>
													<li>24/7 Lifetime service</li>
													<li>We give you free consulting service</li>
													<li>Included top level domain every package</li>
                                                    
                                                    
												</ul>

                                                <h5>Prerequisites</h5>
												<ul>
													<li>We’re creative thinker</li>
													<li>We give you free consulting service</li>
													<li>Included top level domain every package</li>
													<li>Great way to represent your business</li>
                                                    
												</ul>


                                                <div class="button my-4"><a href="#" class="bizwheel-btn "><i class="fa fa-dollar"></i> Buy</a></div>
                                                <div class="button my-4"><a href="https://api.whatsapp.com/send/?phone=+923056558626&text&app_absent=0" class="bizwheel-btn theme-2 effect "><i class="fa fa-user"></i> Discuss Price</a></div>

											</div>
										</div>
							
										
									</div>
								</div>
							</div>
						</div>
												
					</div>		
				</div>
			</div>
		</section>	
		<!--/ End Services -->
		









<?php
include('includes/footer.php');

?>
