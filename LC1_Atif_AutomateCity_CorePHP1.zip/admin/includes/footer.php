<!-- footer part -->
<div class="footer_part">
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="footer_iner text-center">
                <p>© Copyright AutomateCity. Designed & Made with ❤ by <a href="http://techforgery.com/"> Tech Forgery</a></p>
            </div>
        </div>
    </div>
</div>
</div>
</section>
<!-- main content part end -->





<div id="back-top" style="display: none;">
    <a title="Go to Top" href="#">
        <i class="ti-angle-up"></i>
    </a>
</div>

<!-- footer  -->




<?php
    if(basename($_SERVER['PHP_SELF']) == 'index.php'){
    ?>
    <script src="/admin/js/metisMenu.js"></script>
        <!-- waypoints js -->
        <script src="/admin/vendors/count_up/jquery.waypoints.min.js"></script>
        <!-- waypoints js -->
        <script src="/admin/vendors/chartlist/Chart.min.js"></script>
        <!-- counterup js -->
        <script src="/admin/vendors/count_up/jquery.counterup.min.js"></script>

        <!-- nice select -->
        <script src="/admin/vendors/niceselect/js/jquery.nice-select.min.js"></script>

        <!-- datepicker  -->
        <script src="/admin/vendors/datepicker/datepicker.js"></script>
        <script src="/admin/vendors/datepicker/datepicker.en.js"></script>
        <script src="/admin/vendors/datepicker/datepicker.custom.js"></script>

        <script src="/admin/js/chart.min.js"></script>
        <script src="/admin/vendors/chartjs/roundedBar.min.js"></script>

        <!-- progressbar js -->
        <script src="/admin/vendors/progressbar/jquery.barfiller.js"></script>
    

        <!-- vector map  -->
        <script src="/admin/vendors/vectormap-home/vectormap-2.0.2.min.js"></script>
        <script src="/admin/vendors/vectormap-home/vectormap-world-mill-en.js"></script>

        <!-- apex chrat  -->
        <script src="/admin/vendors/apex_chart/apex-chart2.js"></script>
        <script src="/admin/vendors/apex_chart/apex_dashboard.js"></script>

        <script src="/admin/vendors/echart/echarts.min.js"></script>


        <script src="/admin/vendors/chart_am/core.js"></script>
        <script src="/admin/vendors/chart_am/charts.js"></script>
        <script src="/admin/vendors/chart_am/animated.js"></script>
        <script src="/admin/vendors/chart_am/kelly.js"></script>
        <script src="/admin/vendors/chart_am/chart-custom.js"></script>


    <?php } 
?>

<?php
    if(basename($_SERVER['PHP_SELF']) == 'themechange.php'){
    ?>
    <script src="dist/js/bootstrap-colorpicker.js"></script>

    <?php } 
?>

<!-- scrollabe  -->
<script src="/admin/vendors/scroll/perfect-scrollbar.min.js"></script>
<script src="/admin/vendors/scroll/scrollable-custom.js"></script>
<!-- custom js -->
<script src="/admin/js/dashboard_init.js"></script>
<script src="/admin/js/custom.js"></script>


</body>

</html>
